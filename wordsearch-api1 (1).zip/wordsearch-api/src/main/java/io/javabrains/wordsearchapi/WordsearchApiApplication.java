package io.javabrains.wordsearchapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordsearchApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordsearchApiApplication.class, args);
	}

}
